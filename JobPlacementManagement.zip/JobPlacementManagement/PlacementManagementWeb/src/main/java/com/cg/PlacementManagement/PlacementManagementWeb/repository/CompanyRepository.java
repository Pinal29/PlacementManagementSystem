package com.cg.PlacementManagement.PlacementManagementWeb.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.Company;

@Repository
public interface CompanyRepository extends JpaRepository <Company, Long>{

}

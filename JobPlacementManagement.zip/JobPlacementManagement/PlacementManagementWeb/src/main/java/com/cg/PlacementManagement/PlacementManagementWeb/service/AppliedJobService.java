package com.cg.PlacementManagement.PlacementManagementWeb.service;

import java.util.List;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.AppliedJob;

public interface AppliedJobService {

	public void save(AppliedJob appliedJob);
	List<AppliedJob> findAll();
	public List<AppliedJob> findByJobSeekerId(Integer jobseekerId);
	
}

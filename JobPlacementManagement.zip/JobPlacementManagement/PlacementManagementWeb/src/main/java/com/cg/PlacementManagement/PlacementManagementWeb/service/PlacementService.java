package com.cg.PlacementManagement.PlacementManagementWeb.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.Placement;
import com.cg.PlacementManagement.PlacementManagementWeb.repository.PlacementRepository;

@Service
public class PlacementService {

	@Autowired
    private PlacementRepository placementRepository;
	
	public List<Placement> listAll() {
        return placementRepository.findAll();
    }
     
    public void save(Placement plc) {
    	placementRepository.save(plc);
    }
     
    public Placement get(long id) {
        return placementRepository.findById(id).get();
    }
     
    public void delete(long id) {
    	placementRepository.deleteById(id);
    	
    }
   

   
}

package com.cg.PlacementManagement.PlacementManagementWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PlacementManagementWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementManagementWebApplication.class, args);
	}

}

package com.cg.PlacementManagement.PlacementManagementWeb.service;

import java.util.List;
import java.util.Optional;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.JobSeeker;
import com.cg.PlacementManagement.PlacementManagementWeb.entity.Recruiter;

public interface RecruiterService {
	
	List<Recruiter> findAll();

	Optional<Recruiter> getRecruiterById(Long id);

	public JobSeeker verifyJobSeeker(Long recruiterId,Integer jobseekerId);
	
	public Recruiter addRecruiter(Recruiter recruiter);

	Recruiter loginRecruiter(String username, String password);
	

	}

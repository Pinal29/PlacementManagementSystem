package com.cg.PlacementManagement.PlacementManagementWeb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.Admin;
import com.cg.PlacementManagement.PlacementManagementWeb.repository.AdminRepository;

@Service
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;
  
  public Admin login(String username, String password) 
  {
	  Admin admin = adminRepository.findByUsernameAndPassword(username, password);
  	  return admin;
  }
  public Admin addAdmin(Admin admin) {
		
		// TODO Auto-generated method stub
		return adminRepository.save(admin) ;
	}


}

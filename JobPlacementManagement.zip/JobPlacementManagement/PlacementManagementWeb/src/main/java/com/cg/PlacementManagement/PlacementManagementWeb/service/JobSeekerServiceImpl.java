package com.cg.PlacementManagement.PlacementManagementWeb.service;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.Admin;
import com.cg.PlacementManagement.PlacementManagementWeb.entity.JobSeeker;
import com.cg.PlacementManagement.PlacementManagementWeb.exception.JobSeekerNotFoundException;
import com.cg.PlacementManagement.PlacementManagementWeb.repository.JobSeekerRepository;




@Service
public class JobSeekerServiceImpl implements JobSeekerService {

	@Autowired
	private JobSeekerRepository jobSeekerRepository;

	
	

	public JobSeekerServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JobSeekerServiceImpl(JobSeekerRepository jobSeekerRepository) {
		super();
		this.jobSeekerRepository = jobSeekerRepository;
	}

	public JobSeeker save(JobSeeker jobSeeker) {
		// TODO Auto-generated method stub
		return jobSeekerRepository.save(jobSeeker);
	}

	public List<JobSeeker> findAll() {
		// TODO Auto-generated method stub
		return jobSeekerRepository.findAll();
	}

	public Optional<JobSeeker> getJobSeekerById(Integer id) {
		// TODO Auto-generated method stub
		return jobSeekerRepository.findById(id);
	}

	public JobSeeker addJobseeker(JobSeeker jobseeker) {
		// TODO Auto-generated method stub
		return jobSeekerRepository.save(jobseeker);
	}

	public JobSeeker login(String username, String password)throws JobSeekerNotFoundException {
		// TODO Auto-generated method stub
		List<JobSeeker> jobseekerlist=jobSeekerRepository.findAll();
		Iterator<JobSeeker> iterator= jobseekerlist.iterator();
		boolean status=false;
		JobSeeker jobSeeker= null;
		while(iterator.hasNext())
		{
			jobSeeker=iterator.next();
			if(jobSeeker.getUsername().equals(username)&& jobSeeker.getPassword().equals(password))
			{
				status=true;
				break;
			}
		}
		if(status)
		{
			return jobSeeker;
		}
		else
		{
			throw new JobSeekerNotFoundException("Invalid JobSeeker UserName..");
		}
		
	}

	public List<JobSeeker> listAll() {
		// TODO Auto-generated method stub
		return jobSeekerRepository.findAll();
	}
	
	
	
}

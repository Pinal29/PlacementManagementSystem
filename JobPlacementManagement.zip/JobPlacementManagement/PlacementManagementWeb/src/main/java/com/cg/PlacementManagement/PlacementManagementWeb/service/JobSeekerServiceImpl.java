package com.cg.PlacementManagement.PlacementManagementWeb.service;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.JobSeeker;
import com.cg.PlacementManagement.PlacementManagementWeb.exception.JobSeekerNotFoundException;
import com.cg.PlacementManagement.PlacementManagementWeb.repository.JobSeekerRepository;




@Service
public class JobSeekerServiceImpl implements JobSeekerService {

	@Autowired
	private JobSeekerRepository jobSeekerRepository;

	
	

	public JobSeekerServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JobSeekerServiceImpl(JobSeekerRepository jobSeekerRepository) {
		super();
		this.jobSeekerRepository = jobSeekerRepository;
	}
     
	//email validation 
	public boolean emailValidator(String emailId) {
		
		String email_pattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	   
		Pattern pattern = Pattern.compile(email_pattern);
		 Matcher matcher = pattern.matcher(emailId);
		
		matcher = pattern.matcher(emailId);
		return matcher.matches();
	}
	public boolean passwordValidator(String password)
	{
		String password_pattern= "^(?=.*[0-9])"
                       + "(?=.*[a-z])(?=.*[A-Z])"
                       + "(?=.*[@#$%^&+=])"
                       + "(?=\\S+$).{8,20}$";
		Pattern pattern = Pattern.compile(password_pattern);
		 Matcher matcher = pattern.matcher(password);
		
		matcher = pattern.matcher(password);
		return matcher.matches();
	}
	
	public JobSeeker save(JobSeeker jobSeeker) {
		// TODO Auto-generated method stub
		
      	return jobSeekerRepository.save(jobSeeker);
		
	}

	public List<JobSeeker> findAll() {
		// TODO Auto-generated method stub
		return jobSeekerRepository.findAll();
	}

	public Optional<JobSeeker> getJobSeekerById(Integer id) {
		// TODO Auto-generated method stub
		return jobSeekerRepository.findById(id);
	}

	public JobSeeker addJobseeker(JobSeeker jobseeker) {
		// TODO Auto-generated method stubreturn jobSeekerRepository.save(jobseeker);
		String emailId =jobseeker.getEmail();
		String password=jobseeker.getPassword();
		boolean passwordflag= passwordValidator(password);
		boolean flag= emailValidator(emailId);
		if(flag && passwordflag)
	      	return jobSeekerRepository.save(jobseeker);
		else
		{
			return null;
		}
	
	
	}
		

	public JobSeeker loginJobSeeker(String username, String password)throws JobSeekerNotFoundException {
		// TODO Auto-generated method stub
		List<JobSeeker> jobseekerlist=jobSeekerRepository.findAll();
		Iterator<JobSeeker> iterator= jobseekerlist.iterator();
		boolean status=false;
		JobSeeker jobSeeker= null;
		while(iterator.hasNext())
		{
			jobSeeker=iterator.next();
			if(jobSeeker.getUsername().equals(username)&& jobSeeker.getPassword().equals(password))
			{
				status=true;
				break;
			}
		}
		if(status)
		{
			return jobSeeker;
		}
		else
		{
			throw new JobSeekerNotFoundException("Invalid JobSeeker UserName..");
		}
		
	}

	public List<JobSeeker> listAll() {
		// TODO Auto-generated method stub
		return jobSeekerRepository.findAll();
	}
	
	
	
}

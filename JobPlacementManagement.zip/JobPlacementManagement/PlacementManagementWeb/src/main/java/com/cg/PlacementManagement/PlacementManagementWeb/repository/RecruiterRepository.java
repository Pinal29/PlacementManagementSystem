package com.cg.PlacementManagement.PlacementManagementWeb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.Recruiter;

public interface RecruiterRepository extends JpaRepository<Recruiter,Long>{

	Recruiter findByUsernameAndPassword(String username, String password);

}

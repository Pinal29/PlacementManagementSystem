package com.cg.PlacementManagement.PlacementManagementWeb.exception;

public class JobSeekerNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 7462561032910500118L;

	public JobSeekerNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public JobSeekerNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public JobSeekerNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public JobSeekerNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}

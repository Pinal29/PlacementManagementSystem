package com.cg.PlacementManagement.PlacementManagementWeb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.JobSeeker;

public interface JobSeekerRepository extends JpaRepository<JobSeeker, Integer> {

	JobSeeker findByUsernameAndPassword(String username, String password);

}

package com.cg.PlacementManagement.PlacementManagementWeb.service;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.JobSeeker;
import com.cg.PlacementManagement.PlacementManagementWeb.entity.Recruiter;
import com.cg.PlacementManagement.PlacementManagementWeb.exception.JobSeekerNotFoundException;
import com.cg.PlacementManagement.PlacementManagementWeb.exception.RecruiterNotFoundException;
import com.cg.PlacementManagement.PlacementManagementWeb.repository.JobSeekerRepository;
import com.cg.PlacementManagement.PlacementManagementWeb.repository.RecruiterRepository;

@Service
public class RecruiterServiceImpl implements RecruiterService{

	@Autowired
	private RecruiterRepository recruiterRepository;
	
	@Autowired
	private JobSeekerRepository jobSeekerRepository;
	
	public List<Recruiter> findAll() {
		// TODO Auto-generated method stub
		return recruiterRepository.findAll();
	}

	
public boolean emailValidator(String emailId) {
		
		String email_pattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	   
		Pattern pattern = Pattern.compile(email_pattern);
		 Matcher matcher = pattern.matcher(emailId);
		
		matcher = pattern.matcher(emailId);
		return matcher.matches();
	}
	public boolean passwordValidator(String password)
	{
		String password_pattern= "^(?=.*[0-9])"
                       + "(?=.*[a-z])(?=.*[A-Z])"
                       + "(?=.*[@#$%^&+=])"
                       + "(?=\\S+$).{8,20}$";
		Pattern pattern = Pattern.compile(password_pattern);
		 Matcher matcher = pattern.matcher(password);
		
		matcher = pattern.matcher(password);
		return matcher.matches();
	}

	public Recruiter addRecruiter(Recruiter recruiter) {
	
		String emailId =recruiter.getEmail();
		String password=recruiter.getPassword();
		boolean passwordflag= passwordValidator(password);
		boolean flag= emailValidator(emailId);
		if(flag && passwordflag)
	      	return recruiterRepository.save(recruiter);
		else
		{
			return null;
		}
	
	}


	public Optional<Recruiter> getRecruiterById(Long id) {
		// TODO Auto-generated method stub
		return recruiterRepository.findById(id);
	}


	public Recruiter loginRecruiter(String username, String password) {
		List<Recruiter> recruiterlist=recruiterRepository.findAll();
		Iterator<Recruiter> iterator= recruiterlist.iterator();
		boolean status=false;
		Recruiter recruiter= null;
		while(iterator.hasNext())
		{
			recruiter=iterator.next();
			if(recruiter.getUsername().equals(username)&& recruiter.getPassword().equals(password))
			{
				status=true;
				break;
			}
		}
		if(status)
		{
			return recruiter;
		}
		else
		{
			throw new RecruiterNotFoundException("Invalid Recruiter UserName..");
		}
	
	}




	public JobSeeker verifyJobSeeker(Long recruiterId, Integer jobseekerId) 
	{
		// TODO Auto-generated method stub
		Recruiter recruiter = recruiterRepository.findById(recruiterId).get();
		JobSeeker jobSeeker = jobSeekerRepository.findById(jobseekerId).get();
		if(recruiter.getUsername().equals("wipro"))
		{
		     if(jobSeeker.getPassoutyear().equals("2020")&& jobSeeker.getEducation().equals("BE"))
		     {
		    	 jobSeeker.setInterview_status("Interview Scheduled");
		    	 jobSeekerRepository.save(jobSeeker);
		    	 System.out.println("Interview Scheduled");
		     }
		     else
		     {
		    	 jobSeeker.setInterview_status("Application Rejected");
		    	 jobSeekerRepository.save(jobSeeker);
		    	 System.out.println("Application Rejected");
				    
		    
		     }
		     
		}
		else if(recruiter.getUsername().equals("Infosys"))
				{
		     if(jobSeeker.getPassoutyear().equals("2021")&& jobSeeker.getEducation().equals("MBA"))
		     {
		    	 jobSeeker.setInterview_status("Interview Scheduled");
		    	 jobSeekerRepository.save(jobSeeker);
		    	 System.out.println("Interview Scheduled");
				 
		     }
		     else
		     {
		    	 jobSeeker.setInterview_status("Application Rejected");
		    	 jobSeekerRepository.save(jobSeeker);
		    	 System.out.println("Application Rejected");
				 
		    
		     }
		    
		}
		else if(recruiter.getUsername().equals("Accenture"))
				{
		     if(jobSeeker.getPassoutyear().equals("2019"))
		     {
		    	 String [] skills=jobSeeker.getSkills().split(",");
		    	 for(int i=0;i<skills.length;i++)
		    	 {
		    		 if(skills[i].equals("Java Programming"))
		    		 {
		    			 jobSeeker.setInterview_status("Interview Scheduled");
				    	 jobSeekerRepository.save(jobSeeker);
				    	
		    		 }
		    		 else if(skills[i].equals("c"))
		    		 {
		    			 jobSeeker.setInterview_status("Interview Scheduled");
				    	 jobSeekerRepository.save(jobSeeker);
				    	 
				    	 
		    		 }
		    		 else if(skills[i].equals("c++"))
		    		 {
		    			 jobSeeker.setInterview_status("Interview Scheduled");
				    	 jobSeekerRepository.save(jobSeeker);
				    	 
		    		 } 		 
		    			 
		    	 }
		     }
		     else
		     {
		    	 jobSeeker.setInterview_status("Application Rejected");
		    	 jobSeekerRepository.save(jobSeeker);
		    
		     }
		    
		}
		else
		{
			 jobSeeker.setInterview_status("Interview Scheduled");
	    	 jobSeekerRepository.save(jobSeeker);
	    	 System.out.println("Interview Scheduled");
			 
	    
		  
		}
		
		
		return jobSeeker;
	}


	
	
	
	
	
	

}

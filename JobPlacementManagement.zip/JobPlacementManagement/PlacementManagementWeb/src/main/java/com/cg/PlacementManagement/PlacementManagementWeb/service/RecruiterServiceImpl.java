package com.cg.PlacementManagement.PlacementManagementWeb.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.Admin;
import com.cg.PlacementManagement.PlacementManagementWeb.entity.JobSeeker;
import com.cg.PlacementManagement.PlacementManagementWeb.entity.Recruiter;
import com.cg.PlacementManagement.PlacementManagementWeb.repository.JobSeekerRepository;
import com.cg.PlacementManagement.PlacementManagementWeb.repository.RecruiterRepository;

@Service
public class RecruiterServiceImpl implements RecruiterService{

	@Autowired
	private RecruiterRepository recruiterRepository;
	
	@Autowired
	private JobSeekerRepository jobSeekerRepository;
	
	public List<Recruiter> findAll() {
		// TODO Auto-generated method stub
		return recruiterRepository.findAll();
	}

	
	

	public Recruiter addRecruiter(Recruiter recruiter) {
		// TODO Auto-generated method stub
		return recruiterRepository.save(recruiter);
	}


	public Optional<Recruiter> getRecruiterById(Long id) {
		// TODO Auto-generated method stub
		return recruiterRepository.findById(id);
	}


	public Recruiter loginRecruiter(String username, String password) {
		// TODO Auto-generated method stub
		Recruiter recruiter = recruiterRepository.findByUsernameAndPassword(username, password);
	  	  return recruiter;
	}




	public JobSeeker verifyJobSeeker(Long recruiterId, Integer jobseekerId) 
	{
		// TODO Auto-generated method stub
		Recruiter recruiter = recruiterRepository.findById(recruiterId).get();
		JobSeeker jobSeeker = jobSeekerRepository.findById(jobseekerId).get();
		if(recruiter.getUsername().equals("wipro"))
		{
		     if(jobSeeker.getPassoutyear().equals("2020")&& jobSeeker.getEducation().equals("BE"))
		     {
		    	 jobSeeker.setInterview_status("Interview Scheduled");
		    	 jobSeekerRepository.save(jobSeeker);
		     }
		     else
		     {
		    	 jobSeeker.setInterview_status("Rejected");
		    	 jobSeekerRepository.save(jobSeeker);
		    
		     }
		     
		}
		else if(recruiter.getUsername().equals("Infosys"))
				{
		     if(jobSeeker.getPassoutyear().equals("2021")&& jobSeeker.getEducation().equals("MBA"))
		     {
		    	 jobSeeker.setInterview_status("Interview Scheduled");
		    	 jobSeekerRepository.save(jobSeeker);
		     }
		     else
		     {
		    	 jobSeeker.setInterview_status("Rejected");
		    	 jobSeekerRepository.save(jobSeeker);
		    
		     }
		    
		}
		else if(recruiter.getUsername().equals("Accenture"))
				{
		     if(jobSeeker.getPassoutyear().equals("2019"))
		     {
		    	 String [] skills=jobSeeker.getSkills().split(",");
		    	 for(int i=0;i<skills.length;i++)
		    	 {
		    		 if(skills[i].equals("Java Programming"))
		    		 {
		    			 jobSeeker.setInterview_status("Interview Scheduled");
				    	 jobSeekerRepository.save(jobSeeker);
				    	
		    		 }
		    		 else if(skills[i].equals("c"))
		    		 {
		    			 jobSeeker.setInterview_status("Interview Scheduled");
				    	 jobSeekerRepository.save(jobSeeker);
				    	 
		    		 }
		    		 else if(skills[i].equals("c++"))
		    		 {
		    			 jobSeeker.setInterview_status("Interview Scheduled");
				    	 jobSeekerRepository.save(jobSeeker);
				    	 
		    		 } 		 
		    			 
		    	 }
		     }
		     else
		     {
		    	 jobSeeker.setInterview_status("Rejected");
		    	 jobSeekerRepository.save(jobSeeker);
		    
		     }
		    
		}
		else
		{
			 jobSeeker.setInterview_status("Interview Scheduled");
	    	 jobSeekerRepository.save(jobSeeker);
	    
		  
		}
		
		
		return jobSeeker;
	}


	
	
	
	
	
	

}

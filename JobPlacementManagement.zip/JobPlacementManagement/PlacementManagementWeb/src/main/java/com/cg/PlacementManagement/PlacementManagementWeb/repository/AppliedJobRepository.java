package com.cg.PlacementManagement.PlacementManagementWeb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.AppliedJob;

public interface AppliedJobRepository extends JpaRepository<AppliedJob,Long> {

}

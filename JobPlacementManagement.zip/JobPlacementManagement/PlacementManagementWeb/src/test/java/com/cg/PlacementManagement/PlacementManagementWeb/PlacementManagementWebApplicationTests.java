package com.cg.PlacementManagement.PlacementManagementWeb;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.PlacementManagement.PlacementManagementWeb.repository.AdminRepository;
import com.cg.PlacementManagement.PlacementManagementWeb.service.AdminService;
@RunWith(SpringRunner.class)

@SpringBootTest
class PlacementManagementWebApplicationTests {

	@Autowired
	private AdminService service;

	@MockBean
	private AdminRepository repository;

	@Test
	void contextLoads() {
		
	}

}

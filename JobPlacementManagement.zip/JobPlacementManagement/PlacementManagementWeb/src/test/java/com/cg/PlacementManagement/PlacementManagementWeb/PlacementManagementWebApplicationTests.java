package com.cg.PlacementManagement.PlacementManagementWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementManagementWebApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.cg.PlacementManagement.PlacementManagementWeb;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.Admin;
import com.cg.PlacementManagement.PlacementManagementWeb.entity.Company;
import com.cg.PlacementManagement.PlacementManagementWeb.entity.JobSeeker;
import com.cg.PlacementManagement.PlacementManagementWeb.entity.Recruiter;
import com.cg.PlacementManagement.PlacementManagementWeb.service.AdminService;
import com.cg.PlacementManagement.PlacementManagementWeb.service.CompanyService;
import com.cg.PlacementManagement.PlacementManagementWeb.service.JobSeekerService;
import com.cg.PlacementManagement.PlacementManagementWeb.service.RecruiterServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest

public class AdminControllerTestCase {

	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private JobSeekerService jobSeekerService;
	
	@Autowired
	private RecruiterServiceImpl recruiterService;
	
	@Autowired
	private CompanyService companyService;
	
	
	
	@Test
	public void testAdmin() {
		
		Admin admin = new Admin();
		admin.setUsername("admin");
		admin.setPassword("admin");
		admin.setEmail("admin@gmail.com");
		assertNotNull(adminService.addAdmin(admin));

		}
	@Test
	public void testJobSeeker() {
		
		JobSeeker jobSeeker = new JobSeeker();
		jobSeeker.setName("Pavitra Sonar");
		jobSeeker.setUsername("pavitra12");
		jobSeeker.setPassword("pavitra");
		jobSeeker.setEmail("pavita@gmail.com");
		jobSeeker.setEducation("BE");
		jobSeeker.setAge(22);
		jobSeeker.setExperience("fresher");
		jobSeeker.setGender("female");
		jobSeeker.setLocation("Pune");
		jobSeeker.setPassoutyear("2020");
		jobSeeker.setPhoneno(963258741);
		jobSeeker.setSkills("C++,OOP");
		//jobSeeker.setDob('2021/2/21');
		assertNotNull(jobSeekerService.addJobseeker(jobSeeker));

		}
	@Test
	public void testRecruiter() {
		
		Recruiter recruiter = new Recruiter();
		recruiter.setUsername("wipro");
		recruiter.setPassword("wipro123");
		recruiter.setEmail("wipro@gmail.com");
		assertNotNull(recruiterService.addRecruiter(recruiter));

		}
	/*@Test
	public void testCompanyDelete()
	{
		Company company= new Company();
		//company.setId((long) 5);
		assertNotNull(companyService.delete(5));

	}
*/

}

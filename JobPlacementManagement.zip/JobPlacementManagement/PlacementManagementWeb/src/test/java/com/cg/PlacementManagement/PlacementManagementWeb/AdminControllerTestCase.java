package com.cg.PlacementManagement.PlacementManagementWeb;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.PlacementManagement.PlacementManagementWeb.entity.Admin;
import com.cg.PlacementManagement.PlacementManagementWeb.service.AdminService;

@RunWith(SpringRunner.class)
@SpringBootTest

public class AdminControllerTestCase {

	
	@Autowired
	private AdminService adminService;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
		Admin admin = new Admin();
		admin.setUsername("pavitra12");
		admin.setPassword("pavitra");
		admin.setEmail("pavita@gmail.com");
		//when(adminRepository.save(user)).thenReturn(user);
		assertNotNull(adminService.addAdmin(admin));

		//fail("Not yet implemented");
	}

}
